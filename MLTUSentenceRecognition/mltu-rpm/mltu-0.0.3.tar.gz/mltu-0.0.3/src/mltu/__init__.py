__version__ = "1.2.5"

from .annotations.images import Image
from .annotations.images import CVImage
from .annotations.images import PillowImage